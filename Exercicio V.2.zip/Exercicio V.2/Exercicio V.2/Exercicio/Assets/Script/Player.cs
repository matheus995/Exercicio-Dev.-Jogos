﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

	private Animator anim;
	private Rigidbody2D rb2dPlayer;
	private Rigidbody2D rb2d;
	public float velocidade;
	private float h;
	private SpriteRenderer sprite;
	private float vida = 10 ;
	private bool lookRight=true;
	public AnimationClip animClip;
	public AnimationEvent animEvent;
	public GameObject kunai;
	public GameObject kunai2;
	public Transform posicao1;
	public Transform posicao2;
	private bool atirando = false;
	private bool pulando = false;

	public AnimationClip animClip2;
	private AnimationEvent animEvent2;

	private GameObject kunai_jogada;

	private bool dead=false;

	// Use this for initialization
	void Start () {
		animEvent = new AnimationEvent ();
		anim = GetComponent<Animator>();
		rb2dPlayer = GetComponent<Rigidbody2D>();
		sprite = GetComponent<SpriteRenderer> ();

		animEvent.functionName = "setDeadFalse";
		animClip.AddEvent (animEvent);

		animEvent2 = new AnimationEvent ();
		animEvent.functionName = "jogaKunai";
		animClip2.AddEvent (animEvent2);
	}

	// Update is called once per frame
	void Update () {

		if(Input.GetKeyDown(KeyCode.R)){
			dead = false;
			transform.position = new Vector2 (-5.24f,-1.7f);
			vida = 10;
			anim.Play ("IdleAnimation");
		}


		if (!dead) {
			h = Input.GetAxisRaw ("Horizontal");
			rb2dPlayer.velocity = new Vector2 (h * velocidade * Time.deltaTime, rb2dPlayer.velocity.y);

			if (h < 0) {
				transform.localScale = new Vector2 (-0.5200001f, 0.5200001f);
				lookRight = false;
				//transform.localScale = new Vector2 (transform.localScale.x*-1, transform.localScale.y);
			}
			if (h > 0) {
				transform.localScale = new Vector2 (0.5200001f, 0.5200001f);
				lookRight = true;
				//transform.localScale = new Vector2 (transform.localScale.x*1, transform.localScale.y);
			}

			/*if (h < 0 && lookRight) {
				sprite.flipX = true;
				lookRight = false;
			}
			if (h > 0 && !lookRight) {
				sprite.flipX = false;
				lookRight = true;
			}
			*/
			if (h != 0) {
				anim.SetBool ("walk", true);
			} else {
				anim.SetBool ("walk", false);
			}

			if (Input.GetKeyDown (KeyCode.Space) && pulando == false) {
				anim.SetBool ("jump", true);
				rb2dPlayer.AddForce (new Vector2 (0, 300));
			}

			if (Input.GetKeyDown (KeyCode.X)) {
				anim.SetBool ("slide", true);
			} else {
				anim.SetBool ("slide", false);
			}
			if (Input.GetKeyDown (KeyCode.Z)) {
				anim.SetBool ("attack", true);
			} else {
				anim.SetBool ("attack", false);
			}

			if (Input.GetKeyDown (KeyCode.V)) {
				anim.SetBool ("throw", true);
			} else {
				anim.SetBool ("throw", false);
			}
			/*if (Input.GetKeyDown (KeyCode.V) && lookRight==true) {
				jogaKunai ();
				//GameObject tiroTemporario = Instantiate (kunai, posicao1.position, Quaternion.identity);
				//rb2d = tiroTemporario.GetComponent<Rigidbody2D> ();		
				//rb2d.AddForce (new Vector2(500,0));
			}

			if (Input.GetKeyDown (KeyCode.V) && lookRight==false) {
				jogaKunai ();
				//GameObject tiroTemporario = Instantiate (kunai, posicao2.position, Quaternion.identity);
				//rb2d = tiroTemporario.GetComponent<Rigidbody2D> ();		
				//rb2d.AddForce (new Vector2(-500,0));
			}*/

		}
	}
		
	void OnCollisionEnter2D(Collision2D other){
		if (other.gameObject.tag == "chao") {
			anim.SetBool ("jump",false);
		}
		float danoPedra = 10;
		vida = danoPedra-vida;

		if (other.gameObject.tag == "parede") {
			anim.SetBool ("dead",true);
			dead = true;
		}
		pulando = false;
	}

	void OnCollisionExit2D(Collision2D other){
		if (other.gameObject.tag == "chao") {
			anim.SetBool ("jump",true);
			pulando = true;
		}
	}

	void OnTrigger2D(Collider2D other){
		
	}

	public void setDeadFalse(){
		anim.SetBool ("dead",false);
	}
	public void jogaKunai(){
		if (lookRight) {
			kunai_jogada = Instantiate (kunai, posicao1.position, Quaternion.identity);
			kunai_jogada.GetComponent<Rigidbody2D> ().AddForce (new Vector2 (500, 0));
		} 
		else {
			kunai_jogada = Instantiate (kunai2, posicao2.position, Quaternion.identity);
			kunai_jogada.GetComponent<Rigidbody2D> ().AddForce (new Vector2 (-500, 0));
		}
	}
}
